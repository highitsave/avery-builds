# Canopy Clash

A small original, dependency-free browser tag playground.

## Open it
1. Unzip `ape-tag.zip`.
2. Open `index.html` in a current desktop browser. No install or internet is needed.
3. Choose **Host playground** to start a local round with bots.

## Controls
- Hold left/right mouse to plant a hand; release to push off.
- Move mouse to look (click the game to capture mouse). WASD steers in the air.
- Space gives a big leap. Esc opens/closes the menu.
- Adjust movement power and gravity in the menu.

## Three VR adaptation ideas
1. Request WebXR immersive-vr and use each controller grip pose as that hand's world-space target.
2. On grip press, raycast from the controller to a surface and store the hit point; on release, apply a push impulse from hand velocity.
3. Add comfort options: snap/continuous turning, seated reach scaling, and adjustable locomotion strength.
